package com.example.mongoexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
